#!/usr/bin/env bash
set -euo pipefail

cd /mnt/SSD/wsy/projects/PaDIS-MRI-main

export CUDA_VISIBLE_DEVICES=0

MODEL="/mnt/SSD2/wsy/PaDIS-MRI/PaDIS-MRI-runs/overlap_independent_training-runs/brain/32dB/resume10k_overlap_independent_center_symmetric_lam2p5_active64_bgpu1_s16s32s64_p020305_b4_seed123_geomidentical_spatialuniform/00000-aapm_3-uncond-ddpmpp-pedm-gpus1-batch4-fp32-overlap-independent-center-lam2p5-p64-align-symmetric-geom-identical-spatial-uniform/network-snapshot-010000.pkl"
VAL="/mnt/SSD2/wsy/brain_multicoil/fastmri_3T_eval/val_t1-flair_subsamp/32dB"
OUT_ROOT="/mnt/SSD2/wsy/PaDIS-MRI/PaDIS-MRI-recon/new_data/创新/OPA1p25_10k_DPS40x6_sigma1_LGFC_start31_GPU0"

mkdir -p "$OUT_ROOT"

for MASK in 4 7; do
    RUN_ROOT="$OUT_ROOT/R${MASK}"
    mkdir -p "$RUN_ROOT/logs"

    for SAMPLE in $(seq 0 31); do
        SAMPLE_DIR="$RUN_ROOT/sample_${SAMPLE}"
        RESULT="$SAMPLE_DIR/evaluate/comp_plots/results.json"
        LOG="$RUN_ROOT/logs/sample_${SAMPLE}.log"

        if [[ -f "$RESULT" ]]; then
            echo "R${MASK} sample ${SAMPLE}: already complete"
            continue
        fi

        echo "R${MASK} sample ${SAMPLE}: starting"
        python -u eval_lgfc_simply/run_lgfc.py \
            --model_path "$MODEL" \
            --val_dir "$VAL" \
            --save_dir "$SAMPLE_DIR" \
            --sample_index "$SAMPLE" \
            --mask_select "$MASK" \
            --steps 40 \
            --inner_loops 6 \
            --zeta 3.0 \
            --sigma_max 1.0 \
            --sigma_min 0.003 \
            --rho 7.0 \
            --seed 123 \
            --reference_mode ema \
            --ema_beta 0.8 \
            --start_outer 31 \
            --correction_every 1 \
            --unsampled_weight 0.6 \
            --max_relative_update 0.08 \
            --save_diagnostics \
            2>&1 | tee "$LOG"
    done
done

python tools/summarize_lgfc_40x6.py "$OUT_ROOT"
