#!/usr/bin/env python3

import csv
import json
from pathlib import Path
import sys

import numpy as np


def read_metrics(path: Path):
    data = json.loads(path.read_text(encoding="utf-8"))
    per_image = data.get("per_image", {})
    if per_image:
        return next(iter(per_image.values()))
    summary = data.get("summary", {})
    return {
        "psnr": summary["psnr_mean"],
        "ssim": summary["ssim_mean"],
        "nrmse": summary["nrmse_mean"],
    }


def main():
    root = Path(sys.argv[1])
    for mask in (4, 7):
        rows = []
        for sample in range(32):
            path = (
                root
                / f"R{mask}"
                / f"sample_{sample}"
                / "evaluate"
                / "comp_plots"
                / "results.json"
            )
            if not path.exists():
                continue
            metrics = read_metrics(path)
            rows.append(
                {
                    "sample": sample,
                    "psnr": float(metrics["psnr"]),
                    "ssim": float(metrics["ssim"]),
                    "nrmse": float(metrics["nrmse"]),
                }
            )

        if not rows:
            print(f"R{mask}: no completed samples")
            continue

        csv_path = root / f"R{mask}" / "all32_per_image.csv"
        with csv_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)

        summary = {"n": len(rows)}
        for metric in ("psnr", "ssim", "nrmse"):
            values = np.asarray([row[metric] for row in rows], dtype=np.float64)
            summary[f"{metric}_mean"] = float(values.mean())
            summary[f"{metric}_std"] = float(values.std(ddof=0))

        summary_path = root / f"R{mask}" / "summary.json"
        summary_path.write_text(
            json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        print(
            f"R{mask} N={summary['n']} | "
            f"PSNR {summary['psnr_mean']:.4f}±{summary['psnr_std']:.4f} | "
            f"SSIM {summary['ssim_mean']:.5f}±{summary['ssim_std']:.5f} | "
            f"NRMSE {summary['nrmse_mean']:.5f}±{summary['nrmse_std']:.5f}"
        )


if __name__ == "__main__":
    main()
