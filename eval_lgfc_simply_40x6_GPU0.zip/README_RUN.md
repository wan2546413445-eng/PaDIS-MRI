# OPA1.25 10k + DPS40x6 + LGFC on GPU0

Copy the three directories `eval_lgfc_simply`, `bash`, and `tools` into the
PaDIS-MRI repository root, replacing the old `eval_lgfc_simply` directory.

Run the full T1-FLAIR R4/R7 evaluation with:

```bash
cd /mnt/SSD/wsy/projects/PaDIS-MRI-main
OUT=/mnt/SSD2/wsy/PaDIS-MRI/PaDIS-MRI-recon/new_data/创新/OPA1p25_10k_DPS40x6_sigma1_LGFC_start31_GPU0
mkdir -p "$OUT"
nohup bash bash/run_OPA1p25_10k_DPS40x6_sigma1_LGFC_GPU0.sh \
  > "$OUT/queue.log" \
  2>&1 &
```

The experiment uses 40 outer noise levels, 6 inner iterations, sigma 1.0 to
0.003, zeta 3.0, and the unchanged historical LGFC parameters except for the
proportionally mapped start layer 31.
